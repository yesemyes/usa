<table border="1">
    <thead border="0">
    <tr style="text-align: center;">
        <th colspan="4" style="text-align: center;">
            <img src="http://test-usa.tk/img/logo.png" alt="logo" width="250" height="75" style="text-align: center;">
        </th>
    </tr>
    <tr><th></th></tr>
    <tr><th></th></tr>
    <tr><th></th></tr>
    <tr>
        <th colspan="4" style="text-align:center;">Sales Payroll</th>
    </tr>
    <tr>
        <th colspan="4" style="text-align: center"><?php echo e($start_date); ?> to <?php echo e($end_date); ?></th>
    </tr>
    <tr>
        <th colspan="4" style="text-align: center"><?php if(isset($workingDays)&&$workingDays!=null): ?> <?php echo e($workingDays); ?> Workdays <?php endif; ?></th>
    </tr>
    <tr>
        <th>Sales Rep</th>
        <th>Total Collected</th>
        <th>New Business </th>
        <th>New Deals</th>
    </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $result_worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><?php if( isset($item->first_name) ): ?> <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?> <?php endif; ?></td>
            <td><?php if( isset($item->amounts_due) ): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
            <td><?php if( isset($new_bissness[$key]) ): ?> $<?php echo e(number_format($new_bissness[$key],2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
            <td style="text-align: center;"><?php if( isset($newArray[$item->w_id]) ): ?> <?php echo e($newArray[$item->w_id]); ?> <?php else: ?> 0 <?php endif; ?></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><b>Total</b></td>
            <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
            <td><?php if($new_bissness_total['total_all']>0): ?> $<?php echo e(number_format($new_bissness_total['total_all'],2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
            <td style="text-align: center;"><?php if($newArray['total_new']>0): ?> <?php echo e($newArray['total_new']); ?> <?php else: ?> 0 <?php endif; ?></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th>Payment Method</th>
            <th>Total Collected</th>
        </tr>
        <?php $__currentLoopData = $result_payment_method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e($item->pmTitle); ?></td>
                <td><?php if($item->amounts_due>0): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><b>Total</b></td>
            <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th>Payment Type</th>
            <th>Total Collected</th>
        </tr>
        <?php $__currentLoopData = $result_payment_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e($item->ptTitle); ?></td>
                <td><?php if($item->amounts_due>0): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><b>Total</b></td>
            <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th>Marketing Source</th>
            <th>$ Collected</th>
        </tr>
        <?php $__currentLoopData = $result_marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td><?php echo e($item->msTitle); ?></td>
                <td><?php if($item->amounts_due>0): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td><b>Total</b></td>
            <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
        </tr>
    </tbody>
</table>
