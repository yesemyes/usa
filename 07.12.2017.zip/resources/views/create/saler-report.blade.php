<div class="table-responsive">
    <table class="table table-bordered table-hover">
        <thead>
        <tr style="text-align: center;">
            <th colspan="4" style="text-align: center;">
                <img src="http://test-usa.tk/img/logo.png" alt="logo" width="250" height="75" style="text-align: center;">
            </th>
        </tr>
        <tr><th></th></tr>
        <tr><th></th></tr>
        <tr><th></th></tr>
        <tr>
            <th colspan="4" style="text-align:center;">Sales Payroll</th>
        </tr>
        <tr>
            <th colspan="4" style="text-align: center">{{$start_date}} to {{$end_date}}</th>
        </tr>
        <tr>
            <th colspan="4" style="text-align: center">@if(isset($workingDays)&&$workingDays!=null) {{$workingDays}} Workdays @endif</th>
        </tr>
        <tr>
            <th style="background:#FFDA65">Sales Rep</th>
            <th style="background:#FFDA65">Total Collected</th>
            <th style="background:#9933FF;">New Business </th>
            <th style="background:#CC0000;">New Deals</th>
        </tr>
        </thead>
        <tbody>
        @foreach($result_worker as $item)
            <tr>
                <td style="background:#FFDA65;">{{$item->first_name}} {{$item->last_name}}</td>
                <td style="background:#FFDA65;">${{$item->amounts_due}}</td>
            </tr>
        @endforeach
        <tr>
            <td style="background:#FFDA65;"><b>Total</b></td>
            <td style="background:#FFDA65;"><b>${{$total_amout[0]->amounts_due}}</b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th style="background:#92D050">Payment Method</th>
            <th style="background:#92D050">Total Collected</th>
        </tr>
        @foreach($result_payment_method as $item)
            <tr>
                <td style="background:#92D050;">{{$item->pmTitle}}</td>
                <td style="background:#92D050;">${{$item->amounts_due}}</td>
            </tr>
        @endforeach
        <tr>
            <td style="background:#92D050;"><b>Total</b></td>
            <td style="background:#92D050;"><b>${{$total_amout[0]->amounts_due}}</b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th style="background:#9CC3E6">Payment Type</th>
            <th style="background:#9CC3E6">Total Collected</th>
        </tr>
        @foreach($result_payment_type as $item)
            <tr>
                <td style="background:#9CC3E6;">{{$item->ptTitle}}</td>
                <td style="background:#9CC3E6;">${{$item->amounts_due}}</td>
            </tr>
        @endforeach
        <tr>
            <td style="background:#9CC3E6;"><b>Total</b></td>
            <td style="background:#9CC3E6;"><b>${{$total_amout[0]->amounts_due}}</b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th style="background:#F4B082">Marketing Source</th>
            <th style="background:#F4B082">$ Collected</th>
        </tr>
        @foreach($result_marketing as $item)
            <tr>
                <td style="background:#F4B082;">{{$item->msTitle}}</td>
                <td style="background:#F4B082;">${{$item->amounts_due}}</td>
            </tr>
        @endforeach
        <tr>
            <td style="background:#F4B082;"><b>Total</b></td>
            <td style="background:#F4B082;"><b>${{$total_amout[0]->amounts_due}}</b></td>
        </tr>
        </tbody>
    </table>
</div>