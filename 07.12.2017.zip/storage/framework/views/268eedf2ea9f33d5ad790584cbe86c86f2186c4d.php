<?php $__env->startSection('title'); ?>
    All Transactions
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if( Session::has('message_success') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Success!</strong> <?php echo e(Session::get('message_success')); ?>

                </div>        
            </div>
        </div>
    <?php elseif( Session::has('message_error') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger fade in alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Danger!</strong> <?php echo e(Session::get('message_error')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">All Transactions</div>

            <div class="panel-body">
                <div class="table-responsive">
                    <table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>New Deal</th>
                                <th>Case ID</th>
                                <th>Client Name</th>
                                <th>Marketing Source</th>
                                <th>Total Price</th>
                                <th>Created at</th>
                                <th>Updated at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php $__currentLoopData = $transactions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <tr <?php if( $item->collected == 1 ): ?> class="success" <?php else: ?> class="warning" <?php endif; ?>>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php if( $item->new_deal == 1 ): ?> Yes <?php else: ?> No <?php endif; ?></td>
                                    <td><?php echo e($item->case_id); ?></td>
                                    <td><?php echo e($item->client_name); ?></td>
                                    <td><?php echo e($item->title); ?></td>
                                    <td><?php echo e($item->total_price); ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td><?php echo e($item->updated_at); ?></td>
                                    <td><a href="<?php echo e(url('/manage-transaction/'.$item->id)); ?>" class="dBlock btn btn-info">Edit</a></td>
                                </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo e($transactions->links('vendor.pagination.custom')); ?>

                </div>
            </div>

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myjsfile'); ?>
<script src="<?php echo e(url('bower_components/bootstrap/dist/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('bower_components/bootstrap/dist/js/bootstrap-datetimepicker.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>