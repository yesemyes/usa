<?php $__env->startSection('title'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-header'); ?>
    Dashboard
<?php $__env->stopSection(); ?>
<?php $__env->startSection('page-content'); ?>
    <?php if( Session::has('message') ): ?>
    <div class="row">
        <div class="col-lg-6">
            <div class="panel panel-default">
                <div class="panel-body">
                    <p><?php echo e(Session::get('message')); ?></p>
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">DISPLAY REPORT</div>

                <div class="panel-body">
                	
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>