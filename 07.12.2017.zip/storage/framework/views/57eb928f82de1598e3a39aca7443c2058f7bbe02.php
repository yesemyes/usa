<?php $__env->startSection('title'); ?>
    Coast One Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if( Session::has('message_success') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Success!</strong> <?php echo e(Session::get('message_success')); ?>

                </div>
            </div>
        </div>
    <?php elseif( Session::has('message_error') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger fade in alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Danger!</strong> <?php echo e(Session::get('message_error')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-12">
            <div class="panel panel-default">
                <div class="panel-heading">Report</div>

                <div class="panel-body">
                    <form action="<?php echo e(url('/reportAction')); ?>" autocomplete="off" method="POST">
                        <?php echo e(csrf_field()); ?>

                        <div class="row tablerow">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <div class='input-group date datetimepicker'>
                                        <input type='text' name="start_date" id="start_date" value="" class="form-control" />
                                        <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>End Date</label>
                                    <div class='input-group date datetimepicker'>
                                        <input type='text' name="end_date" id="end_date" value="" class="form-control" />
                                        <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-1">
                                <div class="form-group">
                                    <label>Age</label>
                                    <input type="text" name="age" value="" readonly class="form-control age" />
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="client_name">Sale Rep</label>
                                    <select name="worker_id" id="worker_id" class="form-control worker">
                                        <option value="">Choose</option>
                                        <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label>Search</label>
                                <div class="form-group">
                                    <input type="submit" value="Search" class="form-control">
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myjsfile'); ?>
    <link href="<?php echo e(url('dist/css/datetimepicker.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(url('bower_components/bootstrap/dist/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('bower_components/bootstrap/dist/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(url('dist/js/transaction.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>