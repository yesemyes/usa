<div class="table-responsive">
    <table class="table table-bordered table-hover">
        <thead>
        <tr style="text-align: center;">
            <th colspan="4" style="text-align: center;">
                <img src="http://test-usa.tk/img/logo.png" alt="logo" width="250" height="75" style="text-align: center;">
            </th>
        </tr>
        <tr><th></th></tr>
        <tr><th></th></tr>
        <tr><th></th></tr>
        <tr>
            <th colspan="4" style="text-align:center;">Sales Payroll</th>
        </tr>
        <tr>
            <th colspan="4" style="text-align: center"><?php echo e($start_date); ?> to <?php echo e($end_date); ?></th>
        </tr>
        <tr>
            <th colspan="4" style="text-align: center"><?php if(isset($workingDays)&&$workingDays!=null): ?> <?php echo e($workingDays); ?> Workdays <?php endif; ?></th>
        </tr>
        <tr>
            <th style="background:#FFDA65">Sales Rep</th>
            <th style="background:#FFDA65">Total Collected</th>
            <th style="background:#9933FF;">New Business </th>
            <th style="background:#CC0000;">New Deals</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $result_worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td style="background:#FFDA65;"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></td>
                <td style="background:#FFDA65;">$<?php echo e($item->amounts_due); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td style="background:#FFDA65;"><b>Total</b></td>
            <td style="background:#FFDA65;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th style="background:#92D050">Payment Method</th>
            <th style="background:#92D050">Total Collected</th>
        </tr>
        <?php $__currentLoopData = $result_payment_method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td style="background:#92D050;"><?php echo e($item->pmTitle); ?></td>
                <td style="background:#92D050;">$<?php echo e($item->amounts_due); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td style="background:#92D050;"><b>Total</b></td>
            <td style="background:#92D050;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th style="background:#9CC3E6">Payment Type</th>
            <th style="background:#9CC3E6">Total Collected</th>
        </tr>
        <?php $__currentLoopData = $result_payment_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td style="background:#9CC3E6;"><?php echo e($item->ptTitle); ?></td>
                <td style="background:#9CC3E6;">$<?php echo e($item->amounts_due); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td style="background:#9CC3E6;"><b>Total</b></td>
            <td style="background:#9CC3E6;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
        </tr>
        <tr>
            <td></td>
        </tr>
        <tr>
            <th style="background:#F4B082">Marketing Source</th>
            <th style="background:#F4B082">$ Collected</th>
        </tr>
        <?php $__currentLoopData = $result_marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td style="background:#F4B082;"><?php echo e($item->msTitle); ?></td>
                <td style="background:#F4B082;">$<?php echo e($item->amounts_due); ?></td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <tr>
            <td style="background:#F4B082;"><b>Total</b></td>
            <td style="background:#F4B082;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
        </tr>
        </tbody>
    </table>
</div>