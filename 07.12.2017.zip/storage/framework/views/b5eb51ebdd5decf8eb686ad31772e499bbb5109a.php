<div class="table-responsive">
    <table class="table table-bordered table-hover" border="1">
        <thead>
        <tr>
            <th>#</th>
            <th>Created at</th>
            <th>New Deal</th>
            <th>Case ID</th>
            <th>Client Name</th>
            <th>Marketing Source</th>
            <th>Total Price</th>
            <th>Collected (total)</th>
            <th>Lead Date</th>
            <th>Payment Date</th>
            <th>Age</th>
            <th>Payment Method</th>
            <th>Payment Type</th>
            <th>Return Check</th>
            <th>Sale Rap</th>
            <th>Amount due</th>
            <th>Collected (amount)</th>
        </tr>
        </thead>
        <tbody>
        <?php $__currentLoopData = $td_results; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr <?php if( $t_results[$key]->collected == 1 ): ?> class="success" <?php else: ?> class="warning" <?php endif; ?>>
                <td><?php echo e($t_results[$key]->id); ?></td>
                <td><?php echo e($t_results[$key]->created_at); ?></td>
                <td><?php if( $t_results[$key]->new_deal == 1 ): ?> Yes <?php else: ?> No <?php endif; ?></td>
                <td><?php echo e($t_results[$key]->case_id); ?></td>
                <td><?php echo e($t_results[$key]->client_name); ?></td>
                <td><?php echo e($t_results[$key]->mTitle); ?></td>
                <td><?php echo e($t_results[$key]->total_price); ?></td>
                <td><?php if($t_results[$key]->collected==1): ?> Yes <?php else: ?> No <?php endif; ?></td>
            </tr>
            <?php $__currentLoopData = $item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $val): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <tr>
                <td style="border:0"></td>
                <td style="border:0"></td>
                <td style="border:0"></td>
                <td style="border:0"></td>
                <td style="border:0"></td>
                <td style="border:0"></td>
                <td style="border:0"></td>
                <td style="border:0"></td>
                <td><?php echo e($val->lead_date); ?></td>
                <td><?php echo e($val->payment_date); ?></td>
                <td><?php echo e($val->age); ?></td>
                <td><?php echo e($val->title); ?></td>
                <td><?php echo e($val->ptTitle); ?></td>
                <td><?php if($val->check_price != null): ?><?php echo e($val->check_price); ?> <?php if($val->check==1): ?> Customer <?php else: ?> House <?php endif; ?> <?php endif; ?></td>
                <td><?php echo e($val->first_name); ?> <?php echo e($val->last_name); ?></td>
                <td><?php echo e($val->amounts_due); ?></td>
                <td><?php if($val->payed==1): ?> Yes <?php else: ?> No <?php endif; ?></td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </tbody>
    </table>
</div>