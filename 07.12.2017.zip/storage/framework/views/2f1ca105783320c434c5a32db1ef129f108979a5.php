<?php $__env->startSection('title'); ?>
    Coast One Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if( Session::has('message_success') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Success!</strong> <?php echo e(Session::get('message_success')); ?>

                </div>
            </div>
        </div>
    <?php elseif( Session::has('message_error') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger fade in alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Danger!</strong> <?php echo e(Session::get('message_error')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-14">
            <div class="panel panel-default">
                <div class="panel-heading">Report <?php if(isset($workingDays)&&$workingDays!=null): ?> working days in <?php echo e($workingDays); ?> <?php endif; ?></div>

                <div class="panel-body">
                    <form action="<?php echo e(url('/report')); ?>" autocomplete="off" method="GET">
                        <div class="row tablerow">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <div class='input-group date datetimepicker'>
                                        <input type='text' name="start_date" id="start_date" value="<?php echo e($start_date); ?>" class="form-control" />
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>End Date</label>
                                    <div class='input-group date datetimepicker'>
                                        <input type='text' name="end_date" id="end_date" value="<?php echo e($end_date); ?>" class="form-control" />
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label>Search</label>
                                <div class="form-group">
                                    <input type="submit" value="Search" class="form-control">
                                </div>
                            </div>
                        </div>
                        <?php if(isset($result_worker) && count($result_worker)>0): ?>
                            <div class="table-responsive">
                                <h2 class="tCenter">Sales Payroll</h2>
                                <table class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th style="background:#FFDA65">Sales Rep</th>
                                        <th style="background:#FFDA65">Total Collected</th>
                                        <th style="background:#9933FF;">New Business </th>
                                        <th style="background:#CC0000;">New Deals</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $result_worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>

                                        <tr>
                                            <td style="background:#FFDA65;"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></td>
                                            <td style="background:#FFDA65;">$<?php echo e($item->amounts_due); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td style="background:#FFDA65;"><b>Total</b></td>
                                        <td style="background:#FFDA65;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th style="background:#92D050">Payment Method</th>
                                        <th style="background:#92D050">Total Collected</th>
                                    </tr>
                                    <?php $__currentLoopData = $result_payment_method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td style="background:#92D050;"><?php echo e($item->pmTitle); ?></td>
                                            <td style="background:#92D050;">$<?php echo e($item->amounts_due); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td style="background:#92D050;"><b>Total</b></td>
                                        <td style="background:#92D050;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th style="background:#9CC3E6">Payment Type</th>
                                        <th style="background:#9CC3E6">Total Collected</th>
                                    </tr>
                                    <?php $__currentLoopData = $result_payment_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td style="background:#9CC3E6;"><?php echo e($item->ptTitle); ?></td>
                                            <td style="background:#9CC3E6;">$<?php echo e($item->amounts_due); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td style="background:#9CC3E6;"><b>Total</b></td>
                                        <td style="background:#9CC3E6;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th style="background:#F4B082">Marketing Source</th>
                                        <th style="background:#F4B082">$ Collected</th>
                                    </tr>
                                    <?php $__currentLoopData = $result_marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td style="background:#F4B082;"><?php echo e($item->msTitle); ?></td>
                                            <td style="background:#F4B082;">$<?php echo e($item->amounts_due); ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td style="background:#F4B082;"><b>Total</b></td>
                                        <td style="background:#F4B082;"><b>$<?php echo e($total_amout[0]->amounts_due); ?></b></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <input type="submit" name="exel" value="Download Report">
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myjsfile'); ?>
    <link href="<?php echo e(url('dist/css/datetimepicker.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(url('bower_components/bootstrap/dist/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('bower_components/bootstrap/dist/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(url('dist/js/transaction.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>