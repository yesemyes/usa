<?php

namespace App\Http\Controllers;

use App\Transaction_detalis;
use DB;

class HomeController extends Controller
{
	public function dashboard()
	{
		$now_day = date("Y-m-d");
		$first_day = date('Y-m-01', strtotime($now_day));
		$middle_day = date('Y-m-15', strtotime($now_day));
		$last_day = date('Y-m-t', strtotime($now_day));

		$total_amout = Transaction_detalis::select(DB::raw("SUM(amounts_due) as amounts_due"))
		                                  ->where('payed',1)
		                                  ->whereDate('payment_date',$now_day)
		                                  ->get();

		$result_worker = Transaction_detalis::select(DB::raw("SUM(amounts_due) as amounts_due"), 'workers.id as w_id', 'first_name', 'last_name','transaction_detalis.id as td_id')
		                                    ->leftJoin('workers','workers.id','=','transaction_detalis.worker_id')
		                                    ->where('payed',1)
		                                    ->whereDate('payment_date',$now_day)
		                                    ->groupby('worker_id')
		                                    ->orderBy('worker_id','asc')
		                                    ->get();

		$pay_period = Transaction_detalis::select(DB::raw("SUM(amounts_due) as amounts_due"), 'workers.id as w_id', 'first_name', 'last_name','transaction_detalis.id as td_id')
		                                 ->leftJoin('workers','workers.id','=','transaction_detalis.worker_id')
		                                 ->where('payed',1)
		                                 ->whereDate('payment_date','>=',$first_day)
		                                 ->whereDate('payment_date','<=',$middle_day)
		                                 ->groupby('worker_id')
		                                 ->orderBy('worker_id','asc')
		                                 ->get();

		$pay_period_total = Transaction_detalis::select(DB::raw("SUM(amounts_due) as amounts_due"))
		                                       ->where('payed',1)
		                                       ->whereDate('payment_date','>=',$first_day)
		                                       ->whereDate('payment_date','<=',$middle_day)
		                                       ->get();

		$m_t_d = Transaction_detalis::select(DB::raw("SUM(amounts_due) as amounts_due"), 'workers.id as w_id', 'first_name', 'last_name','transaction_detalis.id as td_id')
		                            ->leftJoin('workers','workers.id','=','transaction_detalis.worker_id')
		                            ->where('payed',1)
		                            ->whereDate('payment_date','>=',$first_day)
		                            ->whereDate('payment_date','<=',$last_day)
		                            ->groupby('worker_id')
		                            ->orderBy('worker_id','asc')
		                            ->get();

		$m_t_d_total = Transaction_detalis::select(DB::raw("SUM(amounts_due) as amounts_due"))
		                                  ->where('payed',1)
		                                  ->whereDate('payment_date','>=',$first_day)
		                                  ->whereDate('payment_date','<=',$last_day)
		                                  ->get();

		$new_bissness_new_deal = Transaction_detalis::select(DB::raw("SUM(amounts_due) as amounts"), 'payment_type_id','worker_id','transaction_id','payment_date')
		                                            ->where('payed',1)
		                                            ->where(function ($query) {
			                                            $query->orWhere('payment_type_id', 1)
			                                                  ->orWhere('payment_type_id', 4)
			                                                  ->orWhere('payment_type_id', 6);
		                                            })
		                                            ->whereDate('payment_date','>=',$first_day)
		                                            ->whereDate('payment_date','<=',$last_day)
		                                            ->groupBy('worker_id')
		                                            ->get();

		$a = 0;
		$ab = 0;
		$new_bissness = [];
		$new_bissness_total['total_all'] = 0;
		$new_deal['total_new'] = 0;

		foreach($new_bissness_new_deal as $key => $val)
		{
			// new bissness
			array_push($new_bissness, $val->amounts);
			$new_bissness_total['total_all'] += $val->amounts;
			// end new bissness

			// new deal
			if($val->payment_type_id==1 || $val->payment_type_id==4)
			{
				$ab = $ab+1;
				if($a != $val->worker_id){
					$new_deal["{$val->worker_id}"] = 1;
					$a = $val->worker_id;
				}
				else {
					$new_deal["{$val->worker_id}"] += 1;
				}
			}

			if($val->payment_type_id == 6 || $val->payment_type_id == 7 || $val->payment_type_id == 11)
			{
				$ab = $ab+0.5;
				if($a != $val->worker_id){
					$new_deal["{$val->worker_id}"] = 0.5;
					$a = $val->worker_id;
				}
				else {
					$new_deal["{$val->worker_id}"] += 0.5;
				}
			}
			// end new deal

			$new_deal['total_new'] = $ab;
		} // end foreach
		$current_date = date('m/d/Y');
		return view('dashboard', compact('current_date','new_deal','new_bissness_total','new_bissness','total_amout','result_worker','pay_period','pay_period_total','m_t_d','m_t_d_total'));
	}
}
