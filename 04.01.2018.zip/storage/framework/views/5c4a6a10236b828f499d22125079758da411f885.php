

<?php $__env->startSection('title'); ?>
    Coast One Dashboard
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <div class="row">
        <div class="col-md-14">
            <div class="panel panel-default">
                <div class="panel-heading">Dashboard</div>

                <div class="panel-body">
                    <?php if(isset($new_deal) && count($new_deal)>0): ?>
                        <div class="table-responsive">
                            <h2 class="tCenter" id="current-date"><?php echo e($current_date); ?></h2>
                            <table class="table table-bordered table-hover">
                                <thead>
                                <tr>
                                    <th>Sales Rep</th>
                                    <th>Total Collected</th>
                                    <th>New Business </th>
                                    <th>New Deals</th>
                                </tr>
                                </thead>
                                <tbody>
                                <?php $__currentLoopData = $result_worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><?php if( isset($item->first_name) ): ?> <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?> <?php endif; ?></td>
                                        <td><?php if( isset($item->amounts_due) ): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                        <td><?php if( isset($new_bissness[$key]) ): ?> $<?php echo e(number_format($new_bissness[$key],2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                        <td style="text-align: center;"><?php if( isset($new_deal[$item->w_id]) ): ?> <?php echo e(str_replace("."," , ",$new_deal[$item->w_id])); ?> <?php else: ?> 0 <?php endif; ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                <tr>
                                    <td><b>Total</b></td>
                                    <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
                                    <td><?php if($new_bissness_total['total_all']>0): ?> $<?php echo e(number_format($new_bissness_total['total_all'],2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                    <td style="text-align: center;"><?php if($new_deal['total_new']>0): ?> <?php echo e(str_replace("."," , ",$new_deal['total_new'])); ?> <?php else: ?> 0 <?php endif; ?></td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>