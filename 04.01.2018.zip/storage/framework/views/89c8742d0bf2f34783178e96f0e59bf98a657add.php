<?php $__env->startSection('title'); ?>
    All workers
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if( Session::has('message_success') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Success!</strong> <?php echo e(Session::get('message_success')); ?>

                </div>        
            </div>
        </div>
    <?php elseif( Session::has('message_error') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger fade in alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Danger!</strong> <?php echo e(Session::get('message_error')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
<div class="row">
    <div class="col-md-12">
        <div class="panel panel-default">
            <div class="panel-heading">All workers</div>

            <div class="panel-body">
                <div class="table-responsive">
                	<table class="table table-bordered table-hover">
                        <thead>
                            <tr>
                                <th>#</th>
                                <th>Firstname</th>
                                <th>Lastname</th>
                                <th>Status</th>
                                <th>Created at</th>
                                <th>Updated at</th>
                                <th>Action</th>
                            </tr>
                        </thead>
                        <tbody>
                        	<?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                <?php if( $item->id != 1 ): ?>
                                <tr <?php if( $item->working == 0 ): ?> class="danger" <?php endif; ?>>
                                    <td><?php echo e($item->id); ?></td>
                                    <td><?php echo e($item->first_name); ?></td>
                                    <td><?php echo e($item->last_name); ?></td>
                                    <td><?php if( $item->working == 1 ): ?> working <?php else: ?> released <?php endif; ?></td>
                                    <td><?php echo e($item->created_at); ?></td>
                                    <td><?php echo e($item->updated_at); ?></td>
                                    <td>
                                        <a href="<?php echo e(url('/worker/'.$item->id)); ?>" class="dBlock btn btn-info">Edit</a>
                                        <?php if( $item->working == 0 ): ?>
                                        <form action="<?php echo e(url('/deleteWorker/'.$item->id)); ?>" class="mt5" method="POST">
                                            <?php echo e(csrf_field()); ?>

                                            <input type="hidden" name="f_l_name" value="<?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?>">
                                            <input type="hidden" name="working" value="<?php echo e($item->working); ?>">
                                            <input type="submit" class="dBlock w100 btn btn-danger" value="Delete">
                                        </form>
                                        <?php endif; ?>
                                    </td>
                                </tr>
                                <?php endif; ?>
                        	<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                        </tbody>
                	</table>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>