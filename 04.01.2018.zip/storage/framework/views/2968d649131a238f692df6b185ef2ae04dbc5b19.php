<?php $__env->startSection('title'); ?>
    Create New Transaction
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
	<?php if( Session::has('message_success') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Success!</strong> <?php echo e(Session::get('message_success')); ?>

                </div>        
            </div>
        </div>
    <?php elseif( Session::has('message_error') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger fade in alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Danger!</strong> <?php echo e(Session::get('message_error')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-14">
            <div class="panel panel-default">
                <div class="panel-heading">Create New Transaction</div>

                <div class="panel-body">
                    <form action="<?php echo e(url('/createTransaction')); ?>" method="POST">
		                <?php echo e(csrf_field()); ?>

                        <div class="row">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="case_id">Case ID #</label>
                                    <input type="text" id="case_id" class="form-control" required="required" name="case_id" placeholder="Case ID #">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="client_name">Client Name</label>
                                    <input type="text" id="client_name" class="form-control" required="required" name="client_name" placeholder="Jose Isreal Manzano Lopez">
                                </div>
                            </div>
                            <div class="col-md-3">
                                <div class="form-group">
                                    <label for="client_name">Marketing Source</label>
                                    <select name="marketing_source_id" class="form-control" required>
                                        <option value="">Choose</option>
                                        <?php $__currentLoopData = $marketing_sources; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    </select>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label for="total_price">Gross Sale</label>
                                    <div class="input-group date">
                                        <input type="text" id="total_price" class="form-control" required="required" name="total_price" placeholder="Gross Sale">
                                        <span class="input-group-addon"><i class="fa fa-usd"></i></span>
                                    </div>
                                </div>
                            </div>
                        </div>

                        <div id="cont">
    		                <div class="row tablerow">
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <a class="btn btn-success mt25 form-control add"><i class="fa fa-plus"></i></a>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Lead Date</label>
                                        <div class='input-group date datetimepicker'>
                                            <input type='text' name="lead_date[]" class="form-control" required />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Payment Date</label>
                                        <div class='input-group date datetimepicker'>
                                            <input type='text' name="payment_date[]" class="form-control" required />
                                            <span class="input-group-addon">
                                                <span class="glyphicon glyphicon-calendar"></span>
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <div class="col-md-1">
                                    <div class="form-group">
                                        <label>Age</label>
                                        <input type="text" name="age[]" readonly class="form-control age" required />
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Payment Method</label>
                                        <select name="payment_method_id[]" class="form-control pay" required>
                                            <option value="">Choose</option>
                                            <?php $__currentLoopData = $payment_methods; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </select>
                                        <div class="input-group date return_check none">
                                            <input type="text" name="check_price[]" class="form-control amCol" placeholder="Check (m or i)" />
                                            <span class="input-group-addon">
                                                <i class="fa fa-usd"></i>
                                                <input type="checkbox" class="" name="check[]" />
                                            </span>
                                        </div>
                                    </div>
                                </div>
                                <!--  -->
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label>Payment Type</label>
                                        <select name="payment_type_id[]" class="form-control pay_type" required>
                                            <option value="">Choose</option>
                                            <?php $__currentLoopData = $payment_types; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                                <option value="<?php echo e($item->id); ?>"><?php echo e($item->title); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <!--  -->
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="client_name">Sale Rep</label>
                                        <select name="worker_id[]" class="form-control worker" required>
                                            <option value="">Choose</option>
                                            <?php $__currentLoopData = $workers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                            <option value="<?php echo e($item->id); ?>"><?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?></option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                        </select>
                                    </div>
                                </div>
                                <div class="col-md-2">
                                    <div class="form-group">
                                        <label for="client_name" class="amCol">Amount Due (Collected)</label>
                                        <div class="input-group date">
                                            <input type="text" name="amounts_due[]" class="form-control amount_due" required>
                                            <span class="input-group-addon">
                                                <input type="checkbox" class="payed" name="payed[]">
                                            </span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>

		                <div class="form-group">
		                    <input type="submit" value="Create" class="form-control">
		                </div>
		            </form>
                </div>

            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myjsfile'); ?>
<link href="<?php echo e(url('dist/css/datetimepicker.css')); ?>" rel="stylesheet"/>
<script src="<?php echo e(url('bower_components/bootstrap/dist/js/moment.min.js')); ?>"></script>
<script src="<?php echo e(url('bower_components/bootstrap/dist/js/bootstrap-datetimepicker.min.js')); ?>"></script>
<script src="<?php echo e(url('dist/js/transaction.js')); ?>"></script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>