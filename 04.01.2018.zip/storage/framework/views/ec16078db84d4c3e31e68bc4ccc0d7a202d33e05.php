

<?php $__env->startSection('title'); ?>
    Coast One Report
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
    <?php if( Session::has('message_success') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Success!</strong> <?php echo e(Session::get('message_success')); ?>

                </div>
            </div>
        </div>
    <?php elseif( Session::has('message_error') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger fade in alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Danger!</strong> <?php echo e(Session::get('message_error')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-14">
            <div class="panel panel-default">
                <div class="panel-heading">Report <?php if(isset($workingDays)&&$workingDays!=null): ?> working days in <?php echo e($workingDays); ?> <?php endif; ?></div>

                <div class="panel-body">
                    <form action="<?php echo e(url('/report')); ?>" autocomplete="off" method="GET">
                        <div class="row tablerow">
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>Start Date</label>
                                    <div class='input-group date datetimepicker'>
                                        <input type='text' name="start_date" id="start_date" value="<?php echo e($start_date); ?>" class="form-control" />
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <div class="form-group">
                                    <label>End Date</label>
                                    <div class='input-group date datetimepicker'>
                                        <input type='text' name="end_date" id="end_date" value="<?php echo e($end_date); ?>" class="form-control" />
                                        <span class="input-group-addon">
                                            <span class="glyphicon glyphicon-calendar"></span>
                                        </span>
                                    </div>
                                </div>
                            </div>
                            <div class="col-md-2">
                                <label>Search</label>
                                <div class="form-group">
                                    <input type="submit" value="Search" class="form-control">
                                </div>
                            </div>
                        </div>
                        <?php if(isset($new_deal) && count($new_deal)>0): ?>
                            <div class="table-responsive">
                                <h2 class="tCenter">Sales Payroll</h2>
                                <table class="table table-bordered table-hover">
                                    <thead>
                                    <tr>
                                        <th>Sales Rep</th>
                                        <th>Total Collected</th>
                                        <th>New Business </th>
                                        <th>New Deals</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php $__currentLoopData = $result_worker; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td><?php if( isset($item->first_name) ): ?> <?php echo e($item->first_name); ?> <?php echo e($item->last_name); ?> <?php endif; ?></td>
                                            <td><?php if( isset($item->amounts_due) ): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                            <td><?php if( isset($new_bissness[$key]) ): ?> $<?php echo e(number_format($new_bissness[$key],2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                            <td style="text-align: center;"><?php if( isset($new_deal[$item->w_id]) ): ?> <?php echo e(str_replace("."," , ",$new_deal[$item->w_id])); ?> <?php else: ?> 0 <?php endif; ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><b>Total</b></td>
                                        <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
                                        <td><?php if($new_bissness_total['total_all']>0): ?> $<?php echo e(number_format($new_bissness_total['total_all'],2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                        <td style="text-align: center;"><?php if($new_deal['total_new']>0): ?> <?php echo e(str_replace("."," , ",$new_deal['total_new'])); ?> <?php else: ?> 0 <?php endif; ?></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th>Payment Method</th>
                                        <th>Total Collected</th>
                                    </tr>
                                    <?php $__currentLoopData = $result_payment_method; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->pmTitle); ?></td>
                                            <td><?php if($item->amounts_due>0): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><b>Total</b></td>
                                        <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th>Payment Type</th>
                                        <th>Total Collected</th>
                                    </tr>
                                    <?php $__currentLoopData = $result_payment_type; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->ptTitle); ?></td>
                                            <td><?php if($item->amounts_due>0): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><b>Total</b></td>
                                        <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
                                    </tr>
                                    <tr>
                                        <td></td>
                                    </tr>
                                    <tr>
                                        <th>Marketing Source</th>
                                        <th>$ Collected</th>
                                    </tr>
                                    <?php $__currentLoopData = $result_marketing; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
                                        <tr>
                                            <td><?php echo e($item->msTitle); ?></td>
                                            <td><?php if($item->amounts_due>0): ?> $<?php echo e(number_format($item->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
                                    <tr>
                                        <td><b>Total</b></td>
                                        <td><b><?php if($total_amout[0]->amounts_due>0): ?> $<?php echo e(number_format($total_amout[0]->amounts_due,2)); ?> <?php else: ?> $0,00 <?php endif; ?></b></td>
                                    </tr>
                                    </tbody>
                                </table>
                                <input type="submit" name="exel" value="Download Report">
                            </div>
                        <?php endif; ?>
                    </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('myjsfile'); ?>
    <link href="<?php echo e(url('dist/css/datetimepicker.css')); ?>" rel="stylesheet"/>
    <script src="<?php echo e(url('bower_components/bootstrap/dist/js/moment.min.js')); ?>"></script>
    <script src="<?php echo e(url('bower_components/bootstrap/dist/js/bootstrap-datetimepicker.min.js')); ?>"></script>
    <script src="<?php echo e(url('dist/js/transaction.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>