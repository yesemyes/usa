<?php $__env->startSection('title'); ?>
    Create Marketing Source
<?php $__env->stopSection(); ?>

<?php $__env->startSection('page-content'); ?>
	<?php if( Session::has('message_success') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-success fade in alert-dismissable" style="margin-top:18px;">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Success!</strong> <?php echo e(Session::get('message_success')); ?>

                </div>        
            </div>
        </div>
    <?php elseif( Session::has('message_error') ): ?>
        <div class="row">
            <div class="col-xs-12">
                <div class="alert alert-danger fade in alert-dismissable">
                    <a href="#" class="close" data-dismiss="alert" aria-label="close" title="close">×</a>
                    <strong>Danger!</strong> <?php echo e(Session::get('message_error')); ?>

                </div>
            </div>
        </div>
    <?php endif; ?>
    <div class="row">
        <div class="col-md-6">
            <div class="panel panel-default">
                <div class="panel-heading">Create Marketing Source</div>
                <div class="panel-body">
                    <form action="<?php echo e(url('/createMarketingSource')); ?>" method="POST">
		                <?php echo e(csrf_field()); ?>

		                <div class="form-group">
		                    <label for="title">Title</label>
		                    <input type="text" id="title" required="required" name="title" class="form-control" placeholder="Marketing Source Name">
		                </div>
		                <div class="form-group">
		                    <input type="submit" value="Create" class="form-control">
		                </div>
		            </form>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>