<?php

namespace App\Http\Controllers\Show;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;
use Illuminate\Support\Facades\Session;
use App\Worker;
use App\Payment_method;
use App\Marketing_source;
use App\Transaction;
use App\Transaction_detalis;

class ShowController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    public function dashboard()
    {
        return view('show.dashboard');
    }
    
    public function workers()
    {
        $workers = Worker::where('id','<>','1')->get();
        if( count($workers) == 0 ) return redirect('/create-worker');
        else return view('show.workers', ['workers'=>$workers]);
    }

    public function worker($id)
    {
    	$worker = Worker::where('id',$id)->where('id','<>','1')->first();
        if($worker!=null) return view('show.worker', ['worker'=>$worker]);
        else return redirect('/workers');
    }

    public function paymentMethod()
    {
        $payment_methods = Payment_method::get();
        if( count($payment_methods) == 0 ) return redirect('/payment-method');
        else return view('show.payment-methods', ['payment_methods'=>$payment_methods]);
    }

    public function marketingSource()
    {
        $marketing_sources = Marketing_source::get();
        if( count($marketing_sources) == 0 ) return redirect('/marketing-source');
        else return view('show.marketing-sources', ['marketing_sources'=>$marketing_sources]);
    }

    public function createTransaction()
    {
        $marketing_sources  = Marketing_source::get();
        $payment_methods    = Payment_method::get();
        $workers            = Worker::get();
        return view('create.transaction', ['marketing_sources' => $marketing_sources, 'payment_methods' => $payment_methods, 'workers' => $workers]);
    }

    public function transactions()
    {
        $transactions = Transaction::select('transactions.*','marketing_sources.title')->leftJoin('marketing_sources','marketing_sources.id','=','transactions.marketing_source_id')->get();
        if( count($transactions) == 0 ) return redirect('create-transaction');
        return view('show.transactions',['transactions'=>$transactions]);
    }

    public function transaction($id)
    {
        $workers = Worker::get();
        $marketing_sources = Marketing_source::get();
        $payment_methods = Payment_method::get();
        $transaction = Transaction::where('id',$id)->first();
        if($transaction->collected == 1) Session::flash('message_success', $transaction->id.' Collected');
        $detalis = Transaction_detalis::select('transaction_detalis.*','transaction_detalis.id as tID','workers.*','payment_methods.title')->
                        leftJoin('workers', 'workers.id', '=', 'transaction_detalis.worker_id')
                        ->leftJoin('payment_methods', 'payment_methods.id', '=', 'transaction_detalis.payment_method_id')
                        ->where('transaction_detalis.transaction_id',$id)->get();
        $lead_date = [];
        $payment_date = [];
        $amounts_sum = [];
        $amounts_due = 0;
        foreach($detalis as $item){
            $leadDate = date("d-m-Y", strtotime($item->lead_date));
            $paymentDate = date("d-m-Y", strtotime($item->payment_date));
            array_push($lead_date, $leadDate);
            array_push($payment_date, $paymentDate);
            $amounts_due += $item->amounts_due;
            array_push($amounts_sum, $amounts_due);
        }
                
        return view('show.transaction',['transaction'=>$transaction,'detalis'=>$detalis,'workers'=>$workers,'marketing_sources'=>$marketing_sources,'payment_methods'=>$payment_methods,'lead_date'=>$lead_date,'payment_date'=>$payment_date,'amounts_due'=>$amounts_due]);
    }

    public function search(Request $request)
    {
        $marketing_sources  = Marketing_source::get();
        $payment_methods    = Payment_method::get();
        $workers            = Worker::get();

        if( isset($request->new_deal) && $request->new_deal == "on" ) $new_deal = "checked";
        else $new_deal = null;
        if( isset($request->collected) && $request->collected == "on" ) $collected = "checked";
        else $collected = null;
        if( isset($request->case_id) ) $case_id = $request->case_id;
        else $case_id = null;
        if( isset($request->client_name) ) $client_name = $request->client_name;
        else $client_name = null;
        if( isset($request->marketing_source_id) ) $marketing_source_id = $request->marketing_source_id;
        else $marketing_source_id = null;
        if( isset($request->total_price) ) $total_price = $request->total_price;
        else $total_price = null;
        if( isset($request->start_date) ) $start_date = $request->start_date;
        else $start_date = null;
        if( isset($request->end_date) ) $end_date = $request->end_date;
        else $end_date = null;
        if( isset($request->age) ) $age = $request->age;
        else $age = null;
        if( isset($request->payment_method_id) ) $payment_method_id = $request->payment_method_id;
        else $payment_method_id = null;
        if( isset($request->worker_id) ) $worker_id = $request->worker_id;
        else $worker_id = null;
        $results = null;

        if( $new_deal!=null || $collected!=null || $case_id!=null || $client_name!=null || $marketing_source_id!=null || $total_price!=null || $start_date!=null || $end_date!=null || $payment_method_id!=null || $worker_id!=null )
        {
            $start = date("Y-m-d", strtotime($start_date));
            $end = date("Y-m-d", strtotime($end_date));
            $query = Transaction::select('transactions.*','marketing_sources.title as msTitle','payment_methods.title as pmTitle','workers.first_name','workers.last_name')
            ->where('transactions.id','<>',0)
            ->leftJoin('transaction_detalis','transaction_detalis.transaction_id','=','transactions.id')
            ->leftJoin('marketing_sources','marketing_sources.id','=','transactions.marketing_source_id')
            ->leftJoin('payment_methods','payment_methods.id','=','transaction_detalis.payment_method_id')
            ->leftJoin('workers','workers.id','=','transaction_detalis.worker_id');

            if($new_deal!=null)             $query->where('transactions.new_deal',1);
            if($collected!=null)            $query->where('transactions.collected',1);
            if($case_id!=null)              $query->where('transactions.case_id',$case_id);
            if($client_name!=null)          $query->where('transactions.client_name',$client_name);
            if($marketing_source_id!=null)  $query->where('transactions.marketing_source_id',$marketing_source_id);
            if($total_price!=null)          $query->where('transactions.total_price',$total_price);
            if($start_date!=null)           $query->whereDate('transactions.created_at','>=',$start);
            if($end_date!=null)             $query->whereDate('transactions.created_at','<=',$end);
            if($payment_method_id!=null)    $query->where('transaction_detalis.payment_method_id',$payment_method_id);
            if($worker_id!=null)            $query->where('transaction_detalis.worker_id',$worker_id);
            $results = $query->groupBy('transactions.id')->get();
        }
        return view('show.search', compact(
                                        'marketing_sources', 'payment_methods', 'workers', 
                                        'new_deal', 'collected', 'case_id', 'client_name', 'marketing_source_id', 'total_price', 
                                        'start_date', 'end_date', 'age', 'payment_method_id', 'worker_id', 'results'
                                    )
        );
    }
}
